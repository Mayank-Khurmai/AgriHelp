function patient(){
    document.getElementById("m-box").style.display = "none";
    document.getElementById("model-doctor-after").style.display = "none";
    document.getElementById("model-patient-after").style.display = "block";
}

function doctor(){
    document.getElementById("m-box").style.display = "none";
    document.getElementById("model-patient-after").style.display = "none";
    document.getElementById("model-doctor-after").style.display = "block";
}

function reset_doctor_patient(){
    document.getElementById("model-patient-after").style.display = "none";
    document.getElementById("model-doctor-after").style.display = "none";
    document.getElementById("m-box").style.display = "block";
}